"""Linework: raster line-art -> clean single-stroke centerline SVG, verified by an Edit/Output/Doctor loop."""
__version__ = "0.9.4"
